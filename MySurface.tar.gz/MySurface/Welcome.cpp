#include <stdlib.h>
#include <stdio.h>

#include <surfaceflinger/SurfaceComposerClient.h>
#include <surfaceflinger/Surface.h>
#include <surfaceflinger/ISurfaceComposer.h>

#include <SkCanvas.h>
#include <SkBitmap.h>
#include <SkRegion.h>

using namespace android;

int main(int argc, char **argv)
{
    int pid = getpid();
    int x = 176, y= 144;

    sp<SurfaceComposerClient> videoClient = new SurfaceComposerClient;

    sp<SurfaceControl> spSurCtrl = videoClient->createSurface(pid, 0, x, y, PIXEL_FORMAT_RGBA_8888, 0);

    SurfaceControl *surControl = spSurCtrl.get();

    const sp<Surface>& sur = surControl->getSurface();

    videoClient->openTransaction();

    surControl->setSize(x, y);
    surControl->setPosition(10, 10);
    surControl->setLayer(100000);

    videoClient->closeTransaction();

    surControl->show();

    SkBitmap *pmap = new SkBitmap();
    pmap->setConfig(SkBitmap::kARGB_8888_Config, x, y);

    Surface::SurfaceInfo info;

    sur->lock(&info);
    pmap->setPixels(info.bits);
    sur->unlockAndPost();

    SkCanvas *canvas = new SkCanvas(*pmap);
    canvas->drawColor(0x80509a47, SkXfermode::kSrc_Mode);

    while(1);

    //delete pmap;
    //delete canvas;
    //delete videoClient;

    return 0;
    return 0;
}
