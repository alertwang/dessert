#define LOG_TAG "Example"

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <utils/Log.h> 

int main(int argc ,char **argv)
{
	int val;
	//printf("example running.....\n");
	LOGI("example running.....\n");
	
	int fd = open("/dev/freg", O_RDWR);
	read(fd, &val, sizeof(val));

	while(1)
	{
		usleep(1000);
		//printf("example running.....\n");
		//LOGI("example running.....\n");
		read(fd, &val, sizeof(val));
	}
	
	return 0;
}
