package yude.wang.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SubActivityInProcess extends Activity implements OnClickListener{
	
	private static final String LOG_TAG = "yude.wang.activity.SubActivityInProcess";
	
	private Button finishButton = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sub);
		
		finishButton = (Button) findViewById(R.id.button_finish);
		finishButton.setOnClickListener(this);
		
		Log.i(LOG_TAG, "Sub Activity In Process Created");
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		if(arg0.equals(finishButton)){
			finish();
		}
	}

}
