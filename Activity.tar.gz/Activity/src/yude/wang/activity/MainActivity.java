package yude.wang.activity;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener{
	
	private Button startInProcessButton = null;
	private Button startInNewProcessButton = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        startInProcessButton = (Button) findViewById(R.id.start_in_process);
        startInNewProcessButton = (Button) findViewById(R.id.start_in_new_process);
        
        startInProcessButton.setOnClickListener(this);
        startInNewProcessButton.setOnClickListener(this);
    }


	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		if(arg0.equals(startInProcessButton)){
			
			Intent i = new Intent("yude.wang.activity.subactivity.in.process");
			startActivity(i);
			
		} else if(arg0.equals(startInNewProcessButton)) {
			Intent i = new Intent("yude.wang.activity.subactivity.in.new.process");
			startActivity(i);
		}
	}
    
}
