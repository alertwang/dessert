package yude.wang.ashmem;

import java.io.IOException;

import android.os.MemoryFile;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import android.util.Log;

public class MemoryService extends IMemoryService.Stub{
	
	private static final String LOG_TAG="yude.wang.ashmem.MemoryService";
	private MemoryFile file = null;

	public MemoryService() {
		try {
			file = new MemoryFile("Ashmem", 4);
			setValue(0);
		} catch (Exception e) {
			// TODO: handle exception
			Log.i(LOG_TAG, "Failed to create memory file.");
			e.printStackTrace();
		}
	}

	@Override
	public ParcelFileDescriptor getFileDescriptor() throws RemoteException {
		// TODO Auto-generated method stub
		ParcelFileDescriptor pfd = null;
		try {
			pfd = file.getParcelFileDescriptor();
		} catch (Exception e) {
			// TODO: handle exception
			Log.i(LOG_TAG, "Failed to get file descriptor.");
			e.printStackTrace();
		}
		
		return pfd;
	}

	@Override
	public void setValue(int val) throws RemoteException {
		// TODO Auto-generated method stub
		if(file ==null)
		{
			return;
		}
		byte[] buffer = new byte[4];
		buffer[0] = (byte)((val >> 24) & 0xFF);
		buffer[1] = (byte)((val >> 16) & 0xFF);
		buffer[2] = (byte)((val >> 8) & 0xFF);
		buffer[3] = (byte)((val >> 0) & 0xFF);
		
		try {
			file.writeBytes(buffer, 0, 0, 4);
			Log.i(LOG_TAG, "set value"+val+" to memory file.");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.i(LOG_TAG, "Failed to write bytes to memory file.");
			e.printStackTrace();
		}
	}

}
