package yude.wang.ashmem;

import java.io.FileDescriptor;

import android.os.Bundle;
import android.os.MemoryFile;
import android.os.ParcelFileDescriptor;
import android.os.ServiceManager;
import android.app.Activity;
import android.content.Intent;

import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Client extends Activity implements OnClickListener{

	private final static String LOG_TAG = "yude.wang.ashmem.client";
	IMemoryService memoryService = null;
	MemoryFile memoryFile = null;
	
	private EditText valueText = null;
	
	private Button readButton = null;
	private Button writeButton = null;
	private Button clearButton = null;
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        IMemoryService ms = getMemoryService();
        if(ms == null){
        	Log.i(LOG_TAG, "start yude.wang.ashmem.server");
        	startService(new Intent("yude.wang.ashmem.Server"));
        } else {
        	Log.i(LOG_TAG, "memory server has started");
        }
        
        valueText = (EditText) findViewById(R.id.edit_value);
        
        readButton = (Button) findViewById(R.id.button_read);
        writeButton = (Button) findViewById(R.id.button_write);
        clearButton = (Button) findViewById(R.id.button_clear);

		readButton.setOnClickListener(this);
        writeButton.setOnClickListener(this);
        clearButton.setOnClickListener(this);
        
    }


    private IMemoryService getMemoryService() {
		// TODO Auto-generated method stub
    	
    	if(memoryService != null){
    		return memoryService;
    	}
    	memoryService = IMemoryService.Stub.asInterface(ServiceManager.getService("AnonymousSharedMemory"));

		Log.i(LOG_TAG, memoryService==null?"Failed to get memory service":"Sucess to get memory service");
    	return memoryService;
	}



	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		if(arg0.equals(readButton)){
			int val = 0;
			MemoryFile mf = getMemoryFile();
			if(mf != null){
				try {
					byte[] buffer = new byte[4];
					mf.readBytes(buffer, 0, 0, 4);
					val = buffer[0] << 24 | buffer[1] << 16 | buffer[2] << 8
							| buffer[3];
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
			String text = String.valueOf(val);
			valueText.setText(text);
			
		} else if (arg0.equals(writeButton)){
			
			String text = valueText.getText().toString();
			int val = Integer.parseInt(text);
			IMemoryService ms = getMemoryService();
			if(ms != null){
				try {
					ms.setValue(val);
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
			
		} else if (arg0.equals(clearButton)){
			String text = " ";
			valueText.setText(text);
		} else {
			
		}
	}


	private MemoryFile getMemoryFile() {
		// TODO Auto-generated method stub
		if(memoryFile != null){
			return memoryFile;
		}
		
		IMemoryService ms = getMemoryService();
		if(ms != null){
			try{
				ParcelFileDescriptor pfd = ms.getFileDescriptor();
				if(pfd == null){
					Log.i(LOG_TAG, "Failed to get memory file descriptor");
					return null;
				}
				try {
					FileDescriptor fd = pfd.getFileDescriptor();
					if (fd == null) {
						Log.i(LOG_TAG, "Failed to get memory file descriptor...");
						return null;
					}
					memoryFile = new MemoryFile(fd, 4, "r");
				} catch (Exception e) {
					// TODO: handle exception
					Log.i(LOG_TAG, "Failed to create memory file descriptor");
					e.printStackTrace();
				}
			} catch (Exception e) {
					// TODO: handle exception
					Log.i(LOG_TAG, "Failed to create memory service");
					e.printStackTrace();
			}
		}
		return memoryFile;
	}
    
}
