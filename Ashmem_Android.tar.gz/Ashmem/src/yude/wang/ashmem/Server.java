package yude.wang.ashmem;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.ServiceManager;
import android.util.Log;

public class Server extends Service{
	
	private static final String LOG_TAG = "yude.wang.ashmem.Server";
	private MemoryService memoryService = null;

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		memoryService = new MemoryService();
		
		try {
			ServiceManager.addService("AnonymousSharedMemory", memoryService);
			Log.i(LOG_TAG, "Sucess to add memory service.");
		} catch (Exception e) {
			// TODO: handle exception
			Log.i(LOG_TAG, "Failed to add memory service.");
			e.printStackTrace();
		}
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		Log.i(LOG_TAG, "Destory memory service.");
	}

	@Override
	@Deprecated
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		Log.i(LOG_TAG, "Start memory service.");
	}

}
