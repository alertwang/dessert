package com.example.counter;

public interface ICounterService {
	public void startCounter(int initVal, ICounterCallBack callback);
	public void stopCounter();
}
