package com.example.counter;

import android.os.Bundle;
import android.os.IBinder;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Counter extends Activity implements OnClickListener, ICounterCallBack{
	
	private static final String LOG_TAG = "com.example.counter.Counter";
	private TextView counterText = null;
	private Button startButton = null;
	private Button stopButton = null;
	
	private ICounterService counterService = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        counterText = (TextView) findViewById(R.id.textview_counter);
        startButton = (Button) findViewById(R.id.button_start);
        stopButton = (Button) findViewById(R.id.button_stop);
        
        startButton.setEnabled(true);
        stopButton.setEnabled(false);
        
        startButton.setOnClickListener(this);
        stopButton.setOnClickListener(this);
        
        Intent binderIntent = new Intent(Counter.this, CounterService.class);
        bindService(binderIntent, serviceConnection, Context.BIND_AUTO_CREATE);
    }
    
    


	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		unbindService(serviceConnection);
	}


	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
		if(arg0.equals(startButton)){
			
			counterService.startCounter(0, this);
			startButton.setEnabled(false);
	        stopButton.setEnabled(true);
	        
			
		} else if(arg0.equals(stopButton)) {
			
			counterService.stopCounter();
			
			startButton.setEnabled(true);
	        stopButton.setEnabled(false);
		}
		
	}
    
	private ServiceConnection serviceConnection = new ServiceConnection() {
		
		@Override
		public void onServiceDisconnected(ComponentName arg0) {
			// TODO Auto-generated method stub
			counterService = null;
			Log.i(LOG_TAG, "counter service disconnect");
		}
		
		@Override
		public void onServiceConnected(ComponentName arg0, IBinder arg1) {
			// TODO Auto-generated method stub
			counterService = ((CounterService.CounterBinder)arg1).getService();
			Log.i(LOG_TAG, "counter service connected");
		}
	};


	@Override
	public void count(int val) {
		// TODO Auto-generated method stub
		String text = String.valueOf(val);
		counterText.setText(text);
	}}
