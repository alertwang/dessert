package com.example.counter;

public interface ICounterCallBack {
	void count(int val);
}
